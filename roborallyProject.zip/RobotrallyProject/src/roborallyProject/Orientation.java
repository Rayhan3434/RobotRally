package roborallyProject;

public enum Orientation {
	Z,Q,S,D

}
