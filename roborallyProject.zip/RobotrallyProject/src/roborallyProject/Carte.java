package roborallyProject;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;

public  class Carte extends JButton implements ActionListener{    
	int vitesse;
	String deplacement;
	int ordre;
	static ArrayList <String> listeCarte=new ArrayList<String>();
	int i=0;

	
	
	
	

	
	
	//Constructeurs
	
	public Carte(int ordre) {
		this.ordre=ordre;
		this.setText(TypeCarte());     //On affiche le type de carte sur les cartes
		this.addActionListener(this);   //this se r�f�re � la carte cr��e, on ajoute un �couteur pour toute carte cr��e
		
		
		
	}


	//Getters et setters

	


	public int getOrdre() {
		return ordre;
	}


	public void setOrdre(int ordre) {
		this.ordre = ordre;
	}
	
	public String getValeur(){
		return this.getText() ;
		
		
		
	}





//Cartes de d�placement: fonction qui g�n�re al�atoirement un nombre parmi 1,2,3 et -1
public static String CarteDeplacement() {
	String deplacement="";
	int nombreAleatoire = (-1) + (int)(Math.random() * ((3 - (-1)) + 1));    //int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1)) :La m�thode nextInt() de la classe Random permet de g�n�rer un entier al�atoire compris entre 0 inclus et l'entier pass� en param�tre exclus. En ajoutant 1 et en enlevant le minimum dans l'entier en param�tre, puis en ajoutant le nombre minimum au r�sultat, on arrive � obtenir un nombre al�atoire compris entre les deux valeurs:
	deplacement+=nombreAleatoire;
	if (deplacement.equals("0")) CarteDeplacement();
	
	
	return deplacement;
}

//Cartes d'orientation: fonction qui g�n�re al�atoirement une valeur parmi:droite,gauche,demi-tour
public static String CarteOrientation() {
	String orientation="";
	int nombreAleatoire=(int)(Math.random()*(2));
	if(nombreAleatoire==0) orientation+="R";
	else if(nombreAleatoire==1) orientation+="L";
	
	return orientation;
	
}



//generer une valeur parmi d�placement ou orientation

public static String TypeCarte() {
	int nombreAleatoire=(int)(Math.random()*2);
	if(nombreAleatoire==0) return CarteDeplacement();   //Si le nombre al�atoire est �gal � 0, la carte sera une carte de d�palcement sinon d'orientation
	else {
		return CarteOrientation();
	}
	
}


public void actionPerformed(ActionEvent e) {      //Ce que font les boutons quand on clique dessus
	if(listeCarte.size()<5) {

	//this.setBackground(Color.red);
	
	this.setBackground(Color.cyan);
	listeCarte.add(this.getText());
	System.out.println(listeCarte);
	
	this.removeActionListener(this);
	}
	
	this.addActionListener(this);

	
	
	

}
}
	

	


	


