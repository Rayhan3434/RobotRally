package roborallyProject;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public static void main (String [] args) throws UnknownHostException, IOException {
		//pour envoyer au serveur
		Socket client = new Socket("127.0.0.1", 1026);
		System.out.println("Quel est ton nom ? ");
		Scanner sc = new Scanner(System.in);
		String nomClient = sc.next();
		DataOutputStream out = new DataOutputStream(client.getOutputStream());
		out.writeUTF(nomClient);
		//On recoit le serveur ici pour savoir si la connexion s'est bien pass� 
		DataInputStream in = new DataInputStream(client.getInputStream());
		String connexion = in.readUTF();
		System.out.println(connexion);
				
}}
