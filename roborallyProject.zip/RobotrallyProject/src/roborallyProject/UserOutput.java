package roborallyProject;

import java.util.concurrent.Callable;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;


public class UserOutput implements Callable<Void> {
	 Scanner scanner;
	    PrintStream stream;
	    Socket sockets;
	   public UserOutput(Socket sockets, Scanner scanner) throws IOException {
	        this.stream = new PrintStream(sockets.getOutputStream());
	        this.scanner = scanner;
	        this.sockets = sockets;
	        
	    }
	   public Void call() {
	        while (!sockets.isClosed()) {
	            String input = scanner.nextLine();
	         if(input.equals("quitter")){
	        		  System.out.println("Session en train de se fermer ...");
	        		  stream.flush();
	         		  stream.println("Fermer");
	         		 try {
	                     sockets.close();	  
	         		  }
	         		catch (IOException e) {
	         			System.err.println("La session s'est mal ferm� ! ");
	         			
	         			}
	         		 
	         		scanner.close();
	                return null;
	                
	         		 }
	         stream.println(input);
	         }
	        return null;
	        
	   }
	                    
	    public void Envoie(String messages) {
	        this.stream.println(messages);
	   
	   
	   
	    }
}
