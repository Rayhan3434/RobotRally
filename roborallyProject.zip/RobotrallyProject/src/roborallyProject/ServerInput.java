package roborallyProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ServerInput {
	 private BufferedReader Reader;
	    private Socket sockets;

	    public ServerInput(Socket socket) throws IOException {
	        this.Reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	        this.sockets = sockets;
	        
	    }
	    public Void call() {
	        while (!sockets.isClosed()) {
	        	  try {
	                  String input = Reader.readLine();
	                  if (input.equals("Ferm� !") ){ 
	                	  this.sockets.close();
	                	  return null;
	                	  
	                  }
	                  if (!input.equals("Input") )
	                      System.out.println(input);
	                  
	        }
	        	  catch (IOException e) {
	                  System.err.println("Probl�mes de connexion !");
	                  return null;
	        }
	        	  
	    }
			return null;
	    }      
}
