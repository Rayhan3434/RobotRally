package roborallyProject;
public class Composants {
	
	//static Robott robot1=new Robott(213,377,9,false,false,"robot1");
	static Drapeau drapeau1=new Drapeau(8,8);
	static Drapeau drapeau2=new Drapeau(295,213);
	static Mur mur1=new Mur(213,131);
	static Mur mur2=new Mur(8,336);
	static Mur mur3=new Mur(172,295);
	static Mur mur4=new Mur(336,131);
	static Piege piege1=new Piege(131,90);
	static Piege piege2=new Piege(254,254);
	static Piege piege3=new Piege(377,377);
	static Tapis tapis1=new Tapis(8,213);

	
	
	
	
	
	


		
		
		
		
		
	


}