package roborallyProject;

import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ComponentListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;



public class Robott extends JLabel  {
	
	int x=213;   //x=8 et y=8 repr�sente l'origine du rep�re
	int y=377;
	Orientation orientation=Orientation.Z;
	private int hp = 9;
	private boolean drapeau = false;
	private boolean drapeau2 = false;
	//private ArrayList<Position> historique = new ArrayList<Position>();
	//private final Object synchro = new Object();
	private String nom;
	private Socket connexion;
	ImageIcon image=new ImageIcon(new ImageIcon(this.getClass().getResource("voiturerouge.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH));  //On redimensionnne notre image ‚Ä° la taille du JLabel

	 

	//Constructeur complet
	
public Robott(int x,int y,Orientation orientation,int hp,boolean drapeau,boolean drapeau2,String nom) {
	//super();
	this.x=x;
	this.y=y;
	this.orientation=orientation;
	this.hp=hp;
	this.drapeau=drapeau;
	this.drapeau2=drapeau2;
	this.nom=nom;
	
	this.setOpaque(true);
	this.setBounds(getX(),getY(),30,30);  //Pour un JPanel de taille 30*30, on suppose que le rep�re 0,0 se situe 8,8
	this.setIcon(image);
	
	
	
}







public ImageIcon getImage() {
	return image;
}







public void setImage(ImageIcon image) {
	this.image = image;
}







public Orientation getOrientation() {
	return orientation;
}







public void setOrientation(Orientation orientation) {
	this.orientation = orientation;
}







//Consstructeur position
public Robott(int x,int y) {
	this.x=x;
	this.y=y;

	this.setOpaque(true);
	this.setBounds(getX(),getY(),30,30);  //Pour un JPanel de taille 30*30, on suppose que le rep�re 0,0 se situe 8,8
	
}
	
	
	
	public boolean isAlive() {
		return this.hp > 0;
	
		}
	public void setDrapeauToTrue() {
		this.drapeau = true;

	}
	public void setDrapeau2ToTrue() {
		this.drapeau2 = true;
		

	}
	
	
	
	
	//Constructeurs
	public int getX() {
		return x;
	}



	public void setX(int x) {
		this.x = x;
	}



	public int getY() {
		return y;
	}



	public void setY(int y) {
		this.y = y;
	}



	public int getHp() {
		return hp;
	}



	public void setHp(int hp) {
		this.hp = hp;
	}



	public boolean isDrapeau() {
		return drapeau;
	}



	public void setDrapeau(boolean drapeau) {
		this.drapeau = drapeau;
	}



	public boolean isDrapeau2() {
		return drapeau2;
	}



	public void setDrapeau2(boolean drapeau2) {
		this.drapeau2 = drapeau2;
	}



	public String getNom() {
		return nom;
	}



	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setPosition(int x,int y) {
		this.y=y;
		this.x=x;
		
	}
	public int sommePosition() {
		return (x+y);
	}
	
	/*public void addPosition(Position coord) {

		this.historique.add(coord);

	}
	public ArrayList<Position> getHistorique() {
		//Ce que le joueur voie
		return historique;
	}
	*/
	
	
	/*public void message(String msg) {
		//Envoies des messages aux clients
		synchronized (synchro) {
			PrintStream out;
			try {
				out = new PrintStream(this.connexion.getOutputStream());
				out.println(msg);
			} catch (IOException e) {
				System.err.print("Error sending message to '" + this.nom + "'");
			}
		}
	}
	public String ecoute() throws IOException {
		//Recois les messages du client
		synchronized (synchro) {
			BufferedReader in = new BufferedReader(new InputStreamReader(this.connexion.getInputStream()));

			String response = in.readLine();
			return response;
		}
	

	}
	*/
}
