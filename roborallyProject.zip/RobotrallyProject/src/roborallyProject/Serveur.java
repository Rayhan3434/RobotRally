package roborallyProject;

//import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

//import RobotRally.evenement.src.projet_jeu_video.Robot;

import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.color.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

import java.awt.Color;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;






public class Serveur implements Runnable {
	//on va avoir besoin d'une liste de thread et d'une liste de Robott, une pour chaque partie lanc‚àö¬©e
	private ServerSocket socketServeur;
	private ArrayList<Robott> gamemasters = new ArrayList<Robott>();
	private ArrayList<Thread> games = new ArrayList<Thread>();
		
	static int nbDrapeau=0;
	public Serveur(int port) throws IOException {
		

		
		Fenetre fen=new Fenetre ();
		fen.setVisible(true); // par d√àfaut, la fenetre JFrame n'est pas visible. Ceci permettra de le rendre visible
		
		
		//System.out.println(fen.getContentPane().getSize());
		
		
		JPanel panBoutons=new JPanel(); //Instanciation d'un objet JPanel, pour mettre des boutons,textes,...
		panBoutons.setLayout(new GridLayout(4,1)); //Strat√àgie de positionnement des √àl√àments. 
										
		fen.add(panBoutons,BorderLayout.WEST); //On met ce pan ‚Ä° gauche pour les boutons
		
		
		
		//ajoutons un jpanel pour mettre la map et le jpanel transparent
		JPanel support=new JPanel();
		support.setBackground(Color.gray);
		support.setLayout(null);  
		fen.add(support,BorderLayout.CENTER);
		
		
		
		
		
		File grille=new File("grille.png");
		String chemin=grille.getAbsolutePath();
		//chemin.replace("\\", "n");
	
		System.out.println(chemin);
		
		JLabel mapLab=new JLabel();  
		
		ImageIcon background=new ImageIcon(new ImageIcon(this.getClass().getResource("grille.png")).getImage().getScaledInstance(414,414,Image.SCALE_SMOOTH));  //On redimensionnne notre image ‚Ä° la taille du JLabel
		mapLab.setBounds(150, 20, 414, 414);  
		mapLab.setLayout(new BorderLayout()); //On met une strategie de positionnement pour pouvoir placer un JPanel transparent
		mapLab.setIcon(background);
		support.add(mapLab);
		mapLab.setVisible(false);  //On ne l'affiche pas avant de cliquer sur le bouton "jouer"

		
		
		
		
		
		//On va cr√àer un JPanel transparent pour pouvoir placer nos robots et pi√ãges. On pourra alors voir la carte ‚Ä° travers
		
		JPanel  panTransparent=new JPanel();
		panTransparent.setLayout(null); //On pourra placer nos composants n'importe oÀò dans la map
		panTransparent.setOpaque(false);    //On rend notre jpanel transparent pour pouvoir voir la carte da jlabel
		mapLab.add(panTransparent,BorderLayout.CENTER);
		//panTransparent.add(getRobot1());
		
		
		//Ajout des composants dans notre panTransparent
		
	
		//Drapeau
		Robott robot1=new Robott(213+123,336,Orientation.Z,9,false,false,"robot1");
		panTransparent.add(robot1);
		
	
		panTransparent.add(Composants.drapeau1);
		panTransparent.add(Composants.drapeau2);
		panTransparent.add(Composants.mur1);
		panTransparent.add(Composants.mur2);
		panTransparent.add(Composants.mur3);
		panTransparent.add(Composants.mur4);
		panTransparent.add(Composants.piege1);
		panTransparent.add(Composants.piege2);
		panTransparent.add(Composants.piege3);
		panTransparent.add(Composants.tapis1);



		
		
		//robot1.setOpaque(true);
		/*robot1.setBackground(Color.BLUE);
		robot1.setBounds(336,49,30,30);  //Pour un JPanel de taille 30*30, on suppose que le rep√ãre 0,0 se situe 8,8
		panTransparent.add(robot1); 
	*/
		
		
		
				
		
		
		
		
		//CrÈation des cartes
		Carte carte1=new Carte(1);
		carte1.setBounds(30, 450, 60, 100);
		support.add(carte1);
		carte1.setVisible(false);      //Les cartes ne sont pas visibles tant qu'on n'a pas appuyÈ sur jouer
		//carte1.addActionListener(carte1);
		
		
		Carte carte2=new Carte(2);
		carte2.setBounds(90,450,60,100);      //ajouter 60 ‡ x pour carte suivante
		support.add(carte2);
		carte2.setVisible(false);
		
		
		Carte carte3=new Carte(3);
		carte3.setBounds(150,450,60,100);      
		support.add(carte3);
		carte3.setVisible(false);

		
		Carte carte4=new Carte(4);
		carte4.setBounds(210,450,60,100);      
		support.add(carte4);
		carte4.setVisible(false);
		
		Carte carte5=new Carte(5);
		carte5.setBounds(270,450,60,100);      
		support.add(carte5);
		carte5.setVisible(false);
		
		Carte carte6=new Carte(6);
		carte6.setBounds(330,450,60,100);      
		support.add(carte6);
		carte6.setVisible(false);
		
		Carte carte7=new Carte(7);
		carte7.setBounds(390,450,60,100);      
		support.add(carte7);
		carte7.setVisible(false);
		
		Carte carte8=new Carte(8);
		carte8.setBounds(450,450,60,100);      
		support.add(carte8);
		carte8.setVisible(false);
		
		Carte carte9=new Carte(9);
		carte9.setBounds(510,450,60,100);      
		support.add(carte9);
		carte9.setVisible(false);
		
		
		
		
		
		//Bouton rouler
		
		JButton boutonRouler=new JButton("rouler");
		boutonRouler.setBounds(10,10,100,60);
		boutonRouler.setVisible(false);
		support.add(boutonRouler);
		
		
		//Zone de texte
		JTextArea zoneTexte=new JTextArea("Choisir 5 cartes puis \nappuyer sur rouler.\nUne carte peut �tre\nselectionn�e plusieurs\n fois.\nSi la voiture passe sur\n un drapeau,\nle nombre de case\n s�parant le drapeau\n et la voiture doit\n �tre �gal � la valeur \n sur la carte sinon le \n drapeau ne sera pas\n r�cup�r�.");
		
		zoneTexte.setBounds(10,100,120,300);
		support.add(zoneTexte);
		zoneTexte.setEditable(false);
		zoneTexte.setVisible(false);
		
		
		//Couleur de base bouton
		Color couleur=carte1.getBackground();
		
		
		//Coder les r�gles du jeu
		
		
		boutonRouler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent rouler) {
				
				if(Carte.listeCarte.size()==5) {
					
				for(String el:Carte.listeCarte) {
					if(nbDrapeau==2) {
						zoneTexte.setText("Bravo, drapeaux\n r�cup�r�s");
						boutonRouler.setVisible(false);
						}
					
					
					else if( robot1.getX()==Composants.drapeau1.getX() && robot1.getY()==Composants.drapeau1.getY() && (nbDrapeau==0 || nbDrapeau==1)) {
												nbDrapeau+=1;
												zoneTexte.setText("drapeau 1\n r�cup�r�,r�cuperez \nle drapeau 2");
												Composants.drapeau1.setVisible(false);
											}
					else if((nbDrapeau==0 || nbDrapeau==1) && robot1.getX()==Composants.drapeau2.getX() && robot1.getY()==Composants.drapeau2.getY()) {
												nbDrapeau+=1;
												zoneTexte.setText("drapeau 2\n r�cup�r�, r�cuperez\n le drapeau 1");
												Composants.drapeau2.setVisible(false);
												
											}
						if(robot1.orientation==Orientation.Z) {
							//Si la valeur de la carte est:
							if(el.equals("1") && robot1.getY()-41>=8){
								robot1.setPosition(robot1.getX(),robot1.getY()-41);
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
				
							}
							else if(el.equals("2") && robot1.getY()-(2*41)>=8){
								robot1.setPosition(robot1.getX(),robot1.getY()-(41*2));
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
								
							}
							else if(el.equals("3") && robot1.getY()-(3*41)>=8 ) {
								robot1.setPosition(robot1.getX(),robot1.getY()-(41*3));
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							else if(el.equals("R")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureD.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.D);
							}
							else if(el.equals("L")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureQ.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.Q);
							}
							else if(el.equals("-1") && robot1.getY()+(41)<=377) {
								robot1.setPosition(robot1.getX(),robot1.getY()+41);
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							
								
									
				
					}
						
						//Si orientation est D
						else if(robot1.orientation==Orientation.D) {
							if(el.equals("1") && robot1.getX()+41<=377){
								robot1.setPosition(robot1.getX()+41,robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
				
							}
							else if(el.equals("2")  && robot1.getX()+(41*2)<=377){
								robot1.setPosition(robot1.getX()+(41*2),robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
								
							}
							else if(el.equals("3")  && robot1.getX()+(41*3)<=377) {
								robot1.setPosition(robot1.getX()+(41*3),robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							else if(el.equals("R")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureS.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.S);
							}
							else if(el.equals("L")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voiturerouge.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.Z);
							}
							else if(el.equals("-1") && robot1.getX()-41>=8) {
								robot1.setPosition(robot1.getX()-41,robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							
						}
						
						//Si orientation est Q
						else if(robot1.orientation==Orientation.Q) {
							if(el.equals("1")  && robot1.getX()-41>=8){
								robot1.setPosition(robot1.getX()-41,robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
				
							}
							else if(el.equals("2") && robot1.getX()-(2*41)>=8){
								robot1.setPosition(robot1.getX()-(41*2),robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
								
							}
							else if(el.equals("3") && robot1.getX()-(3*41)>=8) {
								robot1.setPosition(robot1.getX()-(41*3),robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							else if(el.equals("R")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voiturerouge.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.Z);
							}
							else if(el.equals("L")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureS.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
								
							robot1.setOrientation(Orientation.S);
							}
							else if(el.equals("-1") && robot1.getX()+41<=377) {
								robot1.setPosition(robot1.getX()+41,robot1.getY());
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							
						}
						//Orientation S
						else if(robot1.orientation==Orientation.S) {
							if(el.equals("1") && robot1.getY()+(41)<=377){
								robot1.setPosition(robot1.getX(),robot1.getY()+41);
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
				
							}
							else if(el.equals("2") && robot1.getY()+(41*2)<=377){
								robot1.setPosition(robot1.getX(),robot1.getY()+(41*2));
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
								
							}
							else if(el.equals("3") && robot1.getY()+(41*3)<=377) {
								robot1.setPosition(robot1.getX(),robot1.getY()+(41*3));
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							else if(el.equals("R")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureQ.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.Q);
							}
							else if(el.equals("L")) {
								robot1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("voitureD.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH)));
							robot1.setOrientation(Orientation.D);
							}
							else if(el.equals("-1") && robot1.getY()-(41)>=8) {
								robot1.setPosition(robot1.getX(),robot1.getY()-41);
								robot1.setBounds(robot1.getX(),robot1.getY(),30,30);
							}
							
						}
						
						
						
				//	}	
			}
				
				}
				if(Carte.listeCarte.size()==5) {
					//On r�initialise la couleur des cartes
					carte1.setBackground(couleur);
					carte2.setBackground(couleur);
					carte3.setBackground(couleur);
					carte4.setBackground(couleur);
					carte5.setBackground(couleur);
					carte6.setBackground(couleur);
					carte7.setBackground(couleur);
					carte8.setBackground(couleur);
					carte9.setBackground(couleur);
					
					//Ajout de nouvelles valeurs al�atoires sur les cartes
					carte1.setText(Carte.TypeCarte());
					carte2.setText(Carte.TypeCarte());
					carte3.setText(Carte.TypeCarte());
					carte4.setText(Carte.TypeCarte());
					carte5.setText(Carte.TypeCarte());
					carte6.setText(Carte.TypeCarte());
					carte7.setText(Carte.TypeCarte());
					carte8.setText(Carte.TypeCarte());
					carte9.setText(Carte.TypeCarte());


					
				
				Carte.listeCarte.clear();
				}
				//boutonRouler.removeActionListener(this);
				//boutonRouler.addActionListener(this);
			}
		});
	
		
		
		
	
			//robot1.setPosition(robot1.getX()+41, robot1.getY()+41);
		
		
		
		
	
		
		
	
		/*
		JButton boutonOk=new JButton("rouler");
		boutonOk.setBounds(10,10,100,60);
		support.add(boutonOk);
		boutonOk.setVisible(false);
		
		boutonOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent rouler) {
				
				//Composants.robot1.setPosition(8,8);
			
				
				/*
				for (String deplacement:Carte.listeCarte)  {
					if (deplacement.equals("droite")) {
						
						Composants.robot1.setPosition(8,8);
					}
					
				}
				
				
				
				
			}
			
		});
		*/

	
		
		
		
		//On va cr√àer les boutons ‚Ä° mettre ‚Ä° droite de la JFrame
		
				JButton boutonJouer=new JButton("Jouer");
				panBoutons.add(boutonJouer); //On ajoute un bouton "commencer"
				//boutonJouer.setBackground(Color.YELLOW);
				boutonJouer.setForeground(Color.BLACK);   //couleur de la police
				boutonJouer.setFont(new Font("Ravie",Font.PLAIN,26));  //taille et style de police
				Border lineborder = BorderFactory.createLineBorder(Color.black, 3);  
				boutonJouer.setBorder(lineborder); 
				
				// Evenement quand on clique sur le bouton jouer
						boutonJouer.addActionListener(new ActionListener(){
							
							@Override
							public void actionPerformed(ActionEvent jouer) {
								//fen.remove(pan);
								panBoutons.setVisible(false);
								mapLab.setVisible(true);     // la map est ÔøΩ prÔøΩsent visible
								boutonRouler.setVisible(true);
								zoneTexte.setVisible(true);
								carte1.setVisible(true);     //les cartes sont ‡ prÈsent visibles
								carte2.setVisible(true);
								carte3.setVisible(true);
								carte4.setVisible(true);
								carte5.setVisible(true);
								carte6.setVisible(true);
								carte7.setVisible(true);
								carte8.setVisible(true);
								carte9.setVisible(true);
								
								
								
								
							}	
							
							
						});
						
						
	
						
						
						
						
	//Ajout de d�coration
						JButton boutonAide=new JButton("Aide");
						panBoutons.add(boutonAide); //On ajoute un bouton aide
						boutonAide.setForeground(Color.BLACK);
						boutonAide.setFont(new Font("Ravie",Font.PLAIN,26));
						boutonAide.setBorder(lineborder);
						
						
						JButton boutonApropos=new JButton("A propos");
						panBoutons.add(boutonApropos);
						boutonApropos.setForeground(Color.BLACK);
						boutonApropos.setFont(new Font("Ravie",Font.PLAIN,26));
						boutonApropos.setBorder(lineborder);
						
						JButton boutonParametre=new JButton("param�tres");
						panBoutons.add(boutonParametre);
						boutonParametre.setForeground(Color.BLACK);
						boutonParametre.setFont(new Font("Ravie",Font.PLAIN,26));
						boutonParametre.setBorder(lineborder);
						
		
		
		
		
		
		
		this.socketServeur = new ServerSocket(port);
	}
	
	/*public void startPartie(Robott robot) {
		//on ajoute le thread de la partie dans la liste de threads, puis on le lance.
		Thread thread = new Thread(robot);

		this.games.add(thread);
		thread.start();
	}*/
	/*private Robott nouvellePartie() {
		//met en place UNE nouvelle partie, l'ajoute dans la liste
		Robott robot = new Robott(plateau);

		robot.addPosition();
		
		this.gamemasters.add(robot);
		//fd

		return robot;
	}*/
	/*public void addPlayer(Robott joueur) {
		// g‚àö¬©rer l'ajout d'un player
		boolean hasJoined = false;

		for (Engine engine : this.gamemasters) {
			if (engine.howManyPlayers() < 5 && !engine.partieFinie()) {
				engine.addPlayer(joueur);
				hasJoined = true;

				synchronized (engine.running) {
					engine.running.notifyAll();
					// deverouille le wait dans engine
					//le synchronized permet de prendre un acc‚àö¬©s excxlusif sur le lock le temps de l'execution de ce dernier
					//et donc de proteger les variables temporairement. 
					//le premier thread qui obtient le lock oblige le 2e ‚àö‚Ä† attendre
				}
			}
		}
		if (hasJoined)
			return;

		Robott partie = this.nouvellePartie();
		partie.addPlayer(joueur);
		this.startPartie(partie);
	}*/
	public void run() {
		try {

			System.out.println("Lancement du serveur");
			// 5sec avant timeout du serveur s'il y a personne dessus
			// socketServeur.setSoTimeout(5000);
			// d‚àö¬©finir une boucle sans fin
			while (true) {
				// m‚àö¬©thode accept() qui renvoie une socket lors d'une nouvelle connexion
				Socket socketClient = this.socketServeur.accept();
				// obtenir un flux en entr‚àö¬©e et en sortie ‚àö‚Ä†¬¨‚Ä† partir de la socket

				//this.bienvenue(socketClient);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*public void bienvenue(Socket socket) {
		try {
			//Entr‚àö¬©e du joueur dans la partie a laquelle il s'est connect‚àö¬©.
			//il doit entrer son nom pour commencer le jeu
			System.out.println("Connexion avec le client : " + socket.getInetAddress());

			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintStream out = new PrintStream(socket.getOutputStream());

			String name;
			name = in.readLine();
			out.println("Bonjour ! " + name + " !");
			
		
	

			Robott player = new Robott(name, socket);

			this.addPlayer(player);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	public static void main(String[] args) throws IOException {
		Serveur serveur = new Serveur(1664);
		// serveur.start();

		Thread serverThread = new Thread(serveur);
		serverThread.start();
	}

				
	
}
