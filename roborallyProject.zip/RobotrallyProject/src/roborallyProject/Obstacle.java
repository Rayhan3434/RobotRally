package roborallyProject;

public enum Obstacle {
	Murs, Bordure, Tapis, Piege, Drapeau
}
